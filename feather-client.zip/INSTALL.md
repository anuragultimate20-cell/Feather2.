# FeatherClient — Installation Guide

## Quick Install (Recommended)

1. Download the compiled `featherclient-1.0.0.jar`
2. Install Fabric Loader 0.16.9 for Minecraft 1.21.1:
   - Run the [Fabric Installer](https://fabricmc.net/use/)
   - Select version `1.21.1` and loader `0.16.9`
3. Put the jar in `.minecraft/mods/`
4. Also add `fabric-api-0.107.1+1.21.1.jar` to `/mods/`
5. Launch via Fabric profile

---

## Building from Source

### Requirements
- JDK 21 or newer
- ~4 GB free disk space (Minecraft assets cache)

```bash
# 1. Unzip the project or clone it
cd featherclient/

# 2. On macOS / Linux
chmod +x gradlew
./gradlew build

# On Windows
gradlew.bat build

# 3. Find the output jar
ls build/libs/featherclient-1.0.0.jar
```

Build time: ~5 minutes on first run (asset download), ~30 s on subsequent runs.

---

## Spunky Boost Integration

Place FeatherClient ALONGSIDE the Spunky Boost mods — do not replace any Spunky Boost jar.  
Load order doesn't matter; Fabric resolves it correctly.

Recommended Spunky Boost settings to pair with FeatherClient:

| Setting               | Value          | Reason |
|-----------------------|----------------|--------|
| Sodium — Graphics     | Fast           | Lets FeatherClient HUD render unobstructed |
| Sodium — Chunk-build threads | 2–4   | Free threads for FeatherClient async tasks |
| EntityCulling enabled | Yes            | Stacks with FeatherClient entity-tick reduction |
| Iris shaders          | Off or Lite    | Motion Blur in FeatherClient is off by default |
| ImmediatelyFast       | On             | FeatherClient rendering is compatible |

---

## PojavLauncher Setup

1. In PojavLauncher, select the **Fabric 1.21.1** profile
2. Set Java arguments (in Profile → JVM arguments):
   ```
   -Xmx2G -XX:+UseG1GC -XX:G1NewSizePercent=20 -XX:G1ReservePercent=20 \
   -XX:MaxGCPauseMillis=50 -XX:G1HeapRegionSize=32M \
   -Dfml.ignorePatchDiscrepancies=true -Dfml.ignoreInvalidMinecraftCertificates=true
   ```
3. Add `-Dpojav_launcher=1` to JVM args — FeatherClient will auto-detect and activate Low-End Mode
4. Set render distance to **6 chunks**, simulation distance to **5**
5. In FeatherClient ClickGUI → Performance: enable **Low-End Mode** and **FPS Booster** if needed

---

## First-Run Defaults

FeatherClient auto-detects your device on first launch:

| Detection Result | Modules auto-enabled |
|-----------------|----------------------|
| PojavLauncher   | Low-End Mode, FPS Booster |
| ≤ 4 GB RAM      | Low-End Mode |
| > 8 GB RAM      | All HUD elements, Cosmetics |

Config is saved at: `.minecraft/config/featherclient.json`

---

## Uninstall

Remove `featherclient-1.0.0.jar` from `.minecraft/mods/`.  
Optionally delete `.minecraft/config/featherclient.json` and `.minecraft/config/featherclient/`.
