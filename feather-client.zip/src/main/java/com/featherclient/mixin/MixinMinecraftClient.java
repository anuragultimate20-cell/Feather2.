package com.featherclient.mixin;

import com.featherclient.FeatherClientMod;
import com.featherclient.gui.ClickGuiScreen;
import com.featherclient.gui.HudEditorScreen;
import com.featherclient.performance.PerformanceManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.RunArgs;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hooks into MinecraftClient to:
 *  1. Apply PerformanceManager game options once the client is fully loaded
 *  2. Handle FeatherClient global keybinds (ClickGUI, HUD editor)
 */
@Mixin(MinecraftClient.class)
public class MixinMinecraftClient {

    /** Called once after the full client initialisation sequence completes. */
    @Inject(method = "<init>", at = @At("TAIL"))
    private void feather$onClientInit(RunArgs args, CallbackInfo ci) {
        MinecraftClient mc = (MinecraftClient)(Object) this;
        PerformanceManager pm = FeatherClientMod.getPerformanceManager();
        if (pm != null) pm.applyGameOptions(mc);
    }

    /**
     * Global key handler. Checked every client tick.
     *
     * Keybinds (hard-coded defaults, configurable in future release):
     *   RIGHT_SHIFT  → open ClickGUI
     *   RIGHT_ALT    → open HUD editor
     */
    @Inject(method = "tick", at = @At("HEAD"))
    private void feather$onTick(CallbackInfo ci) {
        MinecraftClient mc = (MinecraftClient)(Object) this;
        if (mc.currentScreen != null) return; // don't open over existing screens

        // RSHIFT → ClickGUI
        if (GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT)
                == GLFW.GLFW_PRESS) {
            mc.setScreen(new ClickGuiScreen());
            return;
        }

        // RALT → HUD Editor
        if (GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_ALT)
                == GLFW.GLFW_PRESS) {
            mc.setScreen(new HudEditorScreen());
        }
    }
}
