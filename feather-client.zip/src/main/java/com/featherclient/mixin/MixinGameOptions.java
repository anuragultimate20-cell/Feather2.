package com.featherclient.mixin;

import com.featherclient.FeatherClientMod;
import com.featherclient.modules.misc.ZoomModule;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hooks into GameOptions to intercept keybind processing for
 * FeatherClient's own bindings (Zoom, Freelook) without conflicting
 * with Minecraft's key event dispatch pipeline.
 *
 * The zoom key (default: C) is detected here each tick and relayed
 * to ZoomModule.setZoomed() which drives the FOV interpolation.
 */
@Mixin(GameOptions.class)
public class MixinGameOptions {

    /** Called each game tick during key-binding polling. */
    @Inject(method = "processOptions", at = @At("TAIL"))
    private void feather$processKeys(CallbackInfo ci) {
        var mm = FeatherClientMod.getModuleManager();
        if (mm == null) return;

        // Check zoom key (C) and relay state to ZoomModule
        mm.getByType(ZoomModule.class).ifPresent(zoom -> {
            if (!zoom.isEnabled()) return;
            boolean held = org.lwjgl.glfw.GLFW.glfwGetKey(
                    net.minecraft.client.MinecraftClient.getInstance().getWindow().getHandle(),
                    org.lwjgl.glfw.GLFW.GLFW_KEY_C
            ) == org.lwjgl.glfw.GLFW.GLFW_PRESS;
            zoom.setZoomed(held);
        });

        // Check freelook key (V) and relay state to FreelookModule
        mm.getByType(com.featherclient.modules.misc.FreelookModule.class).ifPresent(fl -> {
            if (!fl.isEnabled()) return;
            boolean held = org.lwjgl.glfw.GLFW.glfwGetKey(
                    net.minecraft.client.MinecraftClient.getInstance().getWindow().getHandle(),
                    org.lwjgl.glfw.GLFW.GLFW_KEY_V
            ) == org.lwjgl.glfw.GLFW.GLFW_PRESS;
            fl.setActive(held);
        });
    }
}
