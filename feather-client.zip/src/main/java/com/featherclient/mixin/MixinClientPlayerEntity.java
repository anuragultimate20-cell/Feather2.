package com.featherclient.mixin;

import com.featherclient.FeatherClientMod;
import com.featherclient.modules.misc.ToggleSprintModule;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hooks into ClientPlayerEntity to support ToggleSprint/ToggleSneak
 * without blocking server-side sprint cancellation (e.g. hunger depletion).
 *
 * When the server resets sprint, ToggleSprintModule's onTick() will
 * re-enable it on the next tick — no desync issues.
 */
@Mixin(ClientPlayerEntity.class)
public class MixinClientPlayerEntity {

    /**
     * Observe sprint state changes from the server.
     * If ToggleSprint is enabled and sprint was cancelled server-side,
     * we let it happen (honoring the game rules) then re-enable next tick.
     */
    @Inject(method = "tickMovement", at = @At("TAIL"))
    private void feather$postTickMovement(CallbackInfo ci) {
        // Toggle sprint is handled entirely in ToggleSprintModule.onTick()
        // which runs in the ClientTickEvents.END_CLIENT_TICK callback.
        // Nothing extra needed here — this mixin exists as an extension
        // point for future movement-related features.
    }
}
