package com.featherclient.mixin;

import com.featherclient.FeatherClientMod;
import com.featherclient.modules.misc.ZoomModule;
import com.featherclient.modules.Module;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyReturnValue;

/**
 * Hooks into GameRenderer to:
 *  1. Override FOV when ZoomModule is active
 */
@Mixin(GameRenderer.class)
public class MixinGameRenderer {

    /**
     * Intercept the computed FOV and replace it with the zoom interpolation
     * when ZoomModule is enabled.
     */
    @ModifyReturnValue(method = "getFov", at = @At("RETURN"))
    private double feather$modifyFov(double original) {
        var mm = FeatherClientMod.getModuleManager();
        if (mm == null) return original;

        var zoomOpt = mm.getByType(ZoomModule.class);
        if (zoomOpt.isPresent() && zoomOpt.get().isEnabled()) {
            return zoomOpt.get().getCurrentFov();
        }
        return original;
    }
}
