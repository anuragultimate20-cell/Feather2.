package com.featherclient.gui;

import com.featherclient.FeatherClientMod;
import com.featherclient.modules.Module;
import com.featherclient.modules.hud.HudModule;
import com.featherclient.render.HudRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * HUD Editor — lets users drag HUD elements anywhere on screen.
 *
 * Each enabled HudModule is rendered at its current position with a
 * highlight border. Clicking and dragging moves the element; releasing
 * saves the new position via ModuleManager.saveState().
 *
 * No special render infrastructure is needed — we re-use each module's
 * own render() method so the preview matches in-game exactly.
 *
 * Open via: FeatherClient ClickGUI → HUD tab → "Open HUD Editor" button,
 *           or the default keybind (R-Alt).
 */
public class HudEditorScreen extends Screen {

    private static final int HIGHLIGHT   = 0x664A90E2;
    private static final int BORDER      = 0xFF4A90E2;
    private static final int TEXT_HINT   = 0xFFAAAAAA;

    private HudModule dragging      = null;
    private int       dragOffsetX   = 0;
    private int       dragOffsetY   = 0;

    private List<HudModule> hudModules;

    public HudEditorScreen() {
        super(Text.literal("HUD Editor"));
    }

    @Override
    protected void init() {
        // Collect all enabled HUD modules
        hudModules = new ArrayList<>();
        for (Module m : FeatherClientMod.getModuleManager().getModules()) {
            if (m instanceof HudModule hm && hm.isEnabled()) {
                hudModules.add(hm);
            }
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Subtle background overlay
        ctx.fill(0, 0, width, height, 0x88000000);

        var hr = new HudRenderer(ctx, delta);

        // Render each HUD module at its current position + highlight border
        for (HudModule hm : hudModules) {
            // Draw selection highlight
            ctx.fill(hm.getX() - 2, hm.getY() - 2,
                     hm.getX() + hm.getWidth() + 2,
                     hm.getY() + hm.getHeight() + 2,
                     HIGHLIGHT);

            // Draw the actual module content
            hm.render(hr, delta);

            // Border
            drawBorder(ctx, hm.getX() - 2, hm.getY() - 2,
                       hm.getWidth() + 4, hm.getHeight() + 4, BORDER);

            // Module name label below element
            hr.drawText(hm.getName(),
                        hm.getX(),
                        hm.getY() + hm.getHeight() + 3,
                        TEXT_HINT, false);
        }

        // Usage hint
        hr.drawText("Drag elements to reposition • ESC to close",
                    4, height - 12, TEXT_HINT, false);
    }

    private void drawBorder(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x,         y,         x + w, y + 1,     color); // top
        ctx.fill(x,         y + h - 1, x + w, y + h,     color); // bottom
        ctx.fill(x,         y,         x + 1, y + h,     color); // left
        ctx.fill(x + w - 1, y,         x + w, y + h,     color); // right
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (HudModule hm : hudModules) {
            if (hm.contains((int) mx, (int) my)) {
                dragging    = hm;
                dragOffsetX = (int) mx - hm.getX();
                dragOffsetY = (int) my - hm.getY();
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) {
            dragging.setX(Math.max(0, Math.min(width  - dragging.getWidth(),  (int) mx - dragOffsetX)));
            dragging.setY(Math.max(0, Math.min(height - dragging.getHeight(), (int) my - dragOffsetY)));
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging != null) {
            dragging = null;
            // Persist positions
            FeatherClientMod.getModuleManager().saveState();
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean shouldPause() { return false; }
}
