package com.featherclient.gui;

import com.featherclient.FeatherClientMod;
import com.featherclient.cosmetics.CosmeticsManager;
import com.featherclient.render.HudRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/**
 * Cosmetics screen — browse and equip capes, hats, and emotes.
 *
 * All textures are loaded asynchronously (CosmeticsManager) so this
 * screen never stalls the render thread waiting for network I/O.
 * While loading, a lightweight spinner placeholder is shown.
 */
public class CosmeticsScreen extends Screen {

    private static final int PANEL_W = 280;
    private static final int PANEL_H = 200;

    private static final String[] TABS = { "Capes", "Emotes" };
    private int selectedTab = 0;

    private final Screen parent;

    public CosmeticsScreen(Screen parent) {
        super(Text.literal("Cosmetics"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        // Back button
        addDrawableChild(ButtonWidget.builder(Text.literal("← Back"), btn -> close())
                .dimensions(10, 10, 60, 18)
                .build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        var theme = FeatherClientMod.getGuiThemeManager();
        var hr    = new HudRenderer(ctx, delta);

        int px = (width  - PANEL_W) / 2;
        int py = (height - PANEL_H) / 2;

        // Darken background
        ctx.fill(0, 0, width, height, 0x88000000);

        // Panel
        hr.drawRoundedRect(px, py, px + PANEL_W, py + PANEL_H, theme.bgColor, 6);
        hr.drawText("Cosmetics", px + 10, py + 10, theme.textColor, false);

        // Tab headers
        for (int i = 0; i < TABS.length; i++) {
            int tx = px + 10 + i * 90;
            int ty = py + 28;
            boolean active = i == selectedTab;
            if (active) hr.drawRect(tx - 2, ty - 2, tx + 82, ty + 14, theme.accentColor);
            hr.drawText(TABS[i], tx, ty, active ? 0xFF000000 : theme.textSecondary, false);
        }

        // Content area
        CosmeticsManager cm = FeatherClientMod.getCosmeticsManager();
        if (!cm.isLoaded()) {
            hr.drawText("Loading cosmetics...", px + 10, py + 55, theme.textSecondary, false);
        } else {
            switch (selectedTab) {
                case 0 -> renderCapes(hr, px, py);
                case 1 -> renderEmotes(hr, px, py);
            }
        }

        super.render(ctx, mouseX, mouseY, delta);
    }

    private void renderCapes(HudRenderer hr, int px, int py) {
        var theme = FeatherClientMod.getGuiThemeManager();
        CosmeticsManager cm = FeatherClientMod.getCosmeticsManager();
        var active = cm.getActiveCape();
        String label = active != null ? "Active: " + active.id : "No cape equipped";
        hr.drawText(label, px + 10, py + 55, theme.textColor, false);
        hr.drawText("Connect to FeatherClient servers to unlock capes.",
                    px + 10, py + 70, theme.textSecondary, false);
    }

    private void renderEmotes(HudRenderer hr, int px, int py) {
        var theme = FeatherClientMod.getGuiThemeManager();
        hr.drawText("Emotes coming soon.", px + 10, py + 55, theme.textSecondary, false);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int px = (width  - PANEL_W) / 2;
        int py = (height - PANEL_H) / 2;
        for (int i = 0; i < TABS.length; i++) {
            int tx = px + 10 + i * 90;
            int ty = py + 28;
            if (mx >= tx - 2 && mx <= tx + 82 && my >= ty - 2 && my <= ty + 14) {
                selectedTab = i;
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public void close() { client.setScreen(parent); }
}
