package com.featherclient.utils;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.function.Supplier;

/**
 * Generic lock-free (single-thread) object pool.
 *
 * Reduces GC pressure in hot paths (HUD rendering, particle tracking)
 * by reusing objects instead of allocating new ones each frame.
 *
 * Usage:
 *   ObjectPool<StringBuilder> pool = new ObjectPool<>(StringBuilder::new, 16);
 *   StringBuilder sb = pool.obtain();
 *   // ... use sb ...
 *   pool.recycle(sb);
 *
 * NOT thread-safe by design — only used from the render/game tick thread.
 */
public class ObjectPool<T> {

    private final Deque<T>    pool;
    private final Supplier<T> factory;
    private final int         maxSize;

    private int allocated = 0;
    private int recycled  = 0;

    public ObjectPool(Supplier<T> factory, int maxSize) {
        this.factory = factory;
        this.maxSize = maxSize;
        this.pool    = new ArrayDeque<>(maxSize);
    }

    /** Obtain an instance from the pool, allocating a new one if necessary. */
    public T obtain() {
        T obj = pool.pollLast();
        if (obj == null) {
            allocated++;
            return factory.get();
        }
        return obj;
    }

    /**
     * Return an instance to the pool.
     * If the pool is full, the object is simply dropped (GC'd).
     */
    public void recycle(T obj) {
        if (obj == null) return;
        if (pool.size() < maxSize) {
            pool.addLast(obj);
            recycled++;
        }
    }

    public int size()      { return pool.size(); }
    public int allocated() { return allocated;   }
    public int recycled()  { return recycled;    }
}
