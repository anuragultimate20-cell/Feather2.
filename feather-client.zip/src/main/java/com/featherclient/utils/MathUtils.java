package com.featherclient.utils;

/**
 * Lightweight math helpers used across modules.
 * All methods are static and allocation-free.
 */
public final class MathUtils {

    private MathUtils() {}

    // ── Interpolation ────────────────────────────────────────────────

    public static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    public static double lerp(double a, double b, double t) { return a + (b - a) * t; }

    /** Smooth-step: S-curve in [0,1]. Zero derivative at endpoints. */
    public static float smoothStep(float t) {
        t = clamp01(t);
        return t * t * (3 - 2 * t);
    }

    /** Ease-out cubic — fast start, decelerates to stop. */
    public static float easeOut(float t) {
        t = clamp01(t);
        float inv = 1 - t;
        return 1 - inv * inv * inv;
    }

    // ── Clamping ─────────────────────────────────────────────────────

    public static float  clamp01(float  v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }
    public static float  clamp(float  v, float  min, float  max) { return v < min ? min : (v > max ? max : v); }
    public static double clamp(double v, double min, double max) { return v < min ? min : (v > max ? max : v); }
    public static int    clamp(int    v, int    min, int    max) { return v < min ? min : (v > max ? max : v); }

    // ── Angle helpers ─────────────────────────────────────────────────

    /** Wrap angle to (-180, 180]. */
    public static float wrapDegrees(float angle) {
        angle %= 360;
        if (angle < -180) angle += 360;
        if (angle >  180) angle -= 360;
        return angle;
    }

    /** Linear interpolation of angles, choosing the shortest path. */
    public static float lerpAngle(float from, float to, float t) {
        float delta = wrapDegrees(to - from);
        return from + delta * t;
    }

    // ── Geometry ─────────────────────────────────────────────────────

    /** Distance squared (avoids sqrt). */
    public static double distSq(double ax, double ay, double az,
                                 double bx, double by, double bz) {
        double dx = ax - bx, dy = ay - by, dz = az - bz;
        return dx*dx + dy*dy + dz*dz;
    }
}
