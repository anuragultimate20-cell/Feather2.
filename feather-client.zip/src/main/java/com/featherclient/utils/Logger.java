package com.featherclient.utils;

import org.slf4j.LoggerFactory;

/**
 * Thin wrapper around SLF4J so every log line is prefixed with
 * [FeatherClient] and the actual logger is obtained lazily (zero cost
 * at class-load if SLF4J is not yet initialised).
 */
public final class Logger {

    private static final org.slf4j.Logger LOG =
            LoggerFactory.getLogger("FeatherClient");

    private Logger() {}

    public static void info (String msg) { LOG.info (msg); }
    public static void warn (String msg) { LOG.warn (msg); }
    public static void error(String msg) { LOG.error(msg); }
    public static void debug(String msg) { LOG.debug(msg); }
}
