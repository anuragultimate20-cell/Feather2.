package com.featherclient.utils;

/**
 * Color utility functions — all pure, all static, allocation-free.
 * Used by crosshair, waypoints, and GUI theming code.
 */
public final class ColorUtils {

    private ColorUtils() {}

    // ── Packing / unpacking ───────────────────────────────────────────

    public static int argb(int a, int r, int g, int b) {
        return ((a & 0xFF) << 24) | ((r & 0xFF) << 16) | ((g & 0xFF) << 8) | (b & 0xFF);
    }

    public static int alpha(int argb) { return (argb >> 24) & 0xFF; }
    public static int red  (int argb) { return (argb >> 16) & 0xFF; }
    public static int green(int argb) { return (argb >>  8) & 0xFF; }
    public static int blue (int argb) { return  argb        & 0xFF; }

    /** Multiply alpha channel by factor (0.0 – 1.0). */
    public static int withAlpha(int argb, float factor) {
        int a = (int)((argb >>> 24) * factor) & 0xFF;
        return (argb & 0x00FFFFFF) | (a << 24);
    }

    // ── Blending ─────────────────────────────────────────────────────

    /** Linear interpolation between two ARGB colors. */
    public static int lerp(int a, int b, float t) {
        float s = 1 - t;
        return argb(
            (int)(alpha(a) * s + alpha(b) * t),
            (int)(red  (a) * s + red  (b) * t),
            (int)(green(a) * s + green(b) * t),
            (int)(blue (a) * s + blue (b) * t)
        );
    }

    // ── HSB helpers ──────────────────────────────────────────────────

    /**
     * Convert HSB (hue 0-360, saturation 0-1, brightness 0-1) to ARGB.
     * Useful for rainbow/chroma effects — call this from render thread only.
     */
    public static int fromHsb(float hue, float sat, float bri) {
        int rgb = java.awt.Color.HSBtoRGB(hue / 360f, sat, bri);
        return 0xFF000000 | (rgb & 0x00FFFFFF);
    }

    /** Current time-based rainbow hue in [0, 360). */
    public static float rainbowHue(float speed) {
        return (System.currentTimeMillis() / 1000.0f * speed * 360.0f) % 360.0f;
    }
}
