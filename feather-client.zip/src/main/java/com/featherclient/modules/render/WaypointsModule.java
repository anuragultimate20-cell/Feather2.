package com.featherclient.modules.render;

import com.featherclient.modules.Module;
import com.featherclient.utils.Logger;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Waypoints — named world positions shown as markers on screen.
 *
 * Waypoints are persisted per-world in config/featherclient/waypoints/
 * Each waypoint has a name, XYZ position, colour, and optional beam.
 *
 * Rendering is handled by MixinWorldRenderer which calls
 * WaypointsModule.render() during the translucent render phase.
 *
 * Performance: beam rendering is opt-in (expensive fill-rate).
 *              Name text is billboard-rendered only when within 256 blocks.
 */
public class WaypointsModule extends Module {

    public static class Waypoint {
        public String name;
        public double x, y, z;
        public int    color = 0xFFFF5555;
        public boolean beam = false;

        public Waypoint() {}
        public Waypoint(String name, double x, double y, double z, int color) {
            this.name = name; this.x = x; this.y = y; this.z = z; this.color = color;
        }

        public double distanceTo(Vec3d pos) {
            double dx = x - pos.x, dy = y - pos.y, dz = z - pos.z;
            return Math.sqrt(dx*dx + dy*dy + dz*dz);
        }
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final List<Waypoint> waypoints = new ArrayList<>();
    private Path waypointsFile;

    public WaypointsModule() {
        super("Waypoints", Category.RENDER, "Save and display world positions.");
    }

    @Override
    public void onEnable() {
        loadForCurrentWorld();
    }

    public void loadForCurrentWorld() {
        MinecraftClient mc = MinecraftClient.getInstance();
        String worldId = mc.isInSingleplayer()
                ? (mc.getServer() != null ? mc.getServer().getSavePath(null).getFileName().toString() : "singleplayer")
                : (mc.getCurrentServerEntry() != null ? mc.getCurrentServerEntry().address : "server");

        waypointsFile = FabricLoader.getInstance().getConfigDir()
                .resolve("featherclient/waypoints/" + worldId + ".json");

        try {
            Files.createDirectories(waypointsFile.getParent());
            if (Files.exists(waypointsFile)) {
                String json = Files.readString(waypointsFile);
                List<Waypoint> loaded = GSON.fromJson(json,
                        new TypeToken<List<Waypoint>>() {}.getType());
                waypoints.clear();
                if (loaded != null) waypoints.addAll(loaded);
            }
        } catch (IOException e) {
            Logger.warn("Could not load waypoints: " + e.getMessage());
        }
    }

    public void save() {
        if (waypointsFile == null) return;
        try {
            Files.writeString(waypointsFile, GSON.toJson(waypoints));
        } catch (IOException e) {
            Logger.error("Could not save waypoints: " + e.getMessage());
        }
    }

    public void addWaypoint(Waypoint w) { waypoints.add(w); save(); }
    public void removeWaypoint(Waypoint w) { waypoints.remove(w); save(); }

    public List<Waypoint> getWaypoints() { return Collections.unmodifiableList(waypoints); }
}
