package com.featherclient.modules.misc;

import com.featherclient.FeatherClientMod;
import com.featherclient.modules.Module;
import net.minecraft.client.MinecraftClient;

/**
 * Smooth Zoom — temporarily reduces FOV for a scoped-in feel.
 *
 * Uses exponential interpolation (lerp) toward the target FOV so the
 * transition feels smooth without any extra threads or timers.
 * The mixin MixinGameRenderer reads getCurrentFov() to override FOV.
 *
 * Scroll-wheel zoom adjust is supported: scroll while zoomed to
 * fine-tune the target FOV in [5, 45] degree range.
 */
public class ZoomModule extends Module {

    private float currentFov          = 70.0f;
    private float targetFov           = 15.0f;
    private float normalFov           = 70.0f;
    private boolean zoomed            = false;

    private static final float LERP   = 0.12f;

    public ZoomModule() {
        super("Zoom", Category.MOVEMENT, "Hold C to zoom in with smooth interpolation.");
    }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options != null) normalFov = mc.options.getFov().getValue().floatValue();
        targetFov = FeatherClientMod.getConfigManager().getConfig().zoomFov;
        currentFov = normalFov;
    }

    public void setZoomed(boolean z) { this.zoomed = z; }
    public boolean isZoomed()        { return zoomed;   }

    /** Returns interpolated FOV — called every frame from mixin. */
    public float getCurrentFov() {
        float target   = zoomed ? targetFov : normalFov;
        currentFov     = currentFov + (target - currentFov) * LERP;
        return currentFov;
    }

    public void scroll(double delta) {
        if (!zoomed) return;
        targetFov = clamp((float)(targetFov - delta * 2.0), 5f, 45f);
    }

    @Override
    public void onDisable() {
        zoomed     = false;
        currentFov = normalFov;
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
