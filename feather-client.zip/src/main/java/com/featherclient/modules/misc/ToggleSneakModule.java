package com.featherclient.modules.misc;

import com.featherclient.modules.Module;
import net.minecraft.client.MinecraftClient;

/**
 * Toggle Sneak — keeps the player sneaking without holding Shift.
 *
 * Uses the same approach as ToggleSprint: forces sneak state each
 * tick while enabled. Cancels on disable or when player detaches.
 */
public class ToggleSneakModule extends Module {

    private boolean sneaking = false;

    public ToggleSneakModule() {
        super("Toggle Sneak", Category.MOVEMENT, "Automatically keeps you sneaking.");
    }

    /** Called from keybind (or GUI toggle) to flip sneak state. */
    public void toggleSneak() {
        sneaking = !sneaking;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        // Press the sneak key synthetically when toggled
        mc.options.sneakKey.setPressed(sneaking);
    }

    @Override
    public void onDisable() {
        sneaking = false;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.options.sneakKey.setPressed(false);
    }
}
