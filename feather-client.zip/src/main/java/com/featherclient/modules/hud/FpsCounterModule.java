package com.featherclient.modules.hud;

import com.featherclient.render.HudRenderer;
import net.minecraft.client.MinecraftClient;

/**
 * FPS Counter HUD element.
 *
 * Performance notes:
 *  - Reads MinecraftClient.getCurrentFps() (already computed by MC, no cost)
 *  - String formatting only happens when the FPS value changes (cached)
 *  - No allocation on the render thread
 */
public class FpsCounterModule extends HudModule {

    private int    cachedFps   = 0;
    private String cachedLabel = "FPS: 0";

    public FpsCounterModule() {
        super("FPS Counter", "Shows current frames per second.", 4, 4);
    }

    @Override
    public void onTick() {
        int fps = MinecraftClient.getInstance().getCurrentFps();
        if (fps != cachedFps) {
            cachedFps   = fps;
            cachedLabel = "FPS: " + fps;
        }
    }

    @Override
    public void render(HudRenderer renderer, float tickDelta) {
        renderer.drawText(cachedLabel, getX(), getY(), getFpsColor(cachedFps), true);
    }

    /** Color-codes FPS: green ≥ 60, yellow ≥ 30, red < 30. */
    private int getFpsColor(int fps) {
        if (fps >= 60) return 0xFF55FF55;
        if (fps >= 30) return 0xFFFFFF55;
        return 0xFFFF5555;
    }
}
