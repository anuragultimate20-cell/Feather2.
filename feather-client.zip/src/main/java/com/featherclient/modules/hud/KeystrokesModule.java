package com.featherclient.modules.hud;

import com.featherclient.render.HudRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;

/**
 * Keystrokes HUD — shows WASD + LMB + RMB + Space state.
 *
 * Renders as a compact grid of key indicators, each lit when pressed.
 * Designed to be pixel-perfect and allocation-free during rendering.
 *
 * Layout (each cell is 14×14 px with 1 px gap):
 *
 *       [W]
 *   [A] [S] [D]
 *  [LMB]   [RMB]
 *    [ SPACE  ]
 */
public class KeystrokesModule extends HudModule {

    private static final int CELL  = 14;
    private static final int GAP   = 1;
    private static final int STEP  = CELL + GAP;

    // Active key colour (bright white) vs inactive (dim grey)
    private static final int COLOR_ACTIVE   = 0xDDFFFFFF;
    private static final int COLOR_INACTIVE = 0x44FFFFFF;
    private static final int COLOR_BG       = 0x88000000;

    public KeystrokesModule() {
        super("Keystrokes", "Shows which keys are currently pressed.", 4, 80);
        setWidth(STEP * 3 - GAP);
        setHeight(STEP * 4 - GAP);
    }

    @Override
    public void onTick() {
        // No state to cache — reads live key bindings in render()
    }

    @Override
    public void render(HudRenderer renderer, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        int ox = getX();
        int oy = getY();

        // Row 0 — W (centred in column 1)
        drawKey(renderer, ox + STEP, oy,          mc.options.forwardKey, "W");
        // Row 1 — A S D
        drawKey(renderer, ox,        oy + STEP,   mc.options.leftKey,    "A");
        drawKey(renderer, ox + STEP, oy + STEP,   mc.options.backKey,    "S");
        drawKey(renderer, ox + STEP*2, oy + STEP, mc.options.rightKey,   "D");
        // Row 2 — LMB / RMB
        drawKey(renderer, ox,        oy + STEP*2, mc.options.attackKey,  "LMB");
        drawKey(renderer, ox + STEP*2, oy + STEP*2, mc.options.useKey,   "RMB");
        // Row 3 — Space bar (spans full width)
        drawKey(renderer, ox,        oy + STEP*3, mc.options.jumpKey,    "SPACE", STEP*3 - GAP, CELL);
    }

    private void drawKey(HudRenderer r, int x, int y, KeyBinding key, String label) {
        drawKey(r, x, y, key, label, CELL, CELL);
    }

    private void drawKey(HudRenderer r, int x, int y, KeyBinding key, String label, int w, int h) {
        boolean pressed = key.isPressed();
        int bg = pressed ? COLOR_ACTIVE : COLOR_BG;
        r.drawRect(x, y, x + w, y + h, bg);
        r.drawText(label, x + w / 2 - r.getTextWidth(label) / 2, y + (h - 7) / 2,
                   pressed ? 0xFF000000 : COLOR_INACTIVE, false);
    }
}
