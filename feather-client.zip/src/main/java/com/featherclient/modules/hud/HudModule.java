package com.featherclient.modules.hud;

import com.featherclient.modules.Module;
import com.featherclient.render.HudRenderer;

/**
 * Base class for all HUD elements.
 *
 * Each HUD module has:
 *  - A screen position (x, y) in pixels from top-left
 *  - A render() method called each frame by HudRenderer
 *  - Draggable support used by the HUD editor screen
 */
public abstract class HudModule extends Module {

    private int x;
    private int y;
    private int width  = 60;
    private int height = 10;

    protected HudModule(String name, String description, int defaultX, int defaultY) {
        super(name, Category.HUD, description);
        this.x = defaultX;
        this.y = defaultY;
    }

    /**
     * Called every rendered frame. Must be fast — no I/O, minimal allocation.
     *
     * @param renderer  pre-built batched HUD renderer for this frame
     * @param tickDelta interpolation factor between the last two ticks
     */
    public abstract void render(HudRenderer renderer, float tickDelta);

    // ── Position ───────────────────────────────────────────────────

    public int  getX()            { return x;      }
    public int  getY()            { return y;      }
    public int  getWidth()        { return width;  }
    public int  getHeight()       { return height; }
    public void setX(int x)       { this.x = x;   }
    public void setY(int y)       { this.y = y;   }
    public void setWidth(int w)   { width = w;     }
    public void setHeight(int h)  { height = h;    }

    /** Returns true if the given screen coordinate is inside this element. */
    public boolean contains(int px, int py) {
        return px >= x && px <= x + width && py >= y && py <= y + height;
    }
}
