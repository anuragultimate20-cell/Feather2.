package com.featherclient.modules.hud;

import com.featherclient.render.HudRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;

/**
 * Coordinates HUD — X / Y / Z + facing direction.
 *
 * Updates every tick but only reformats strings when values change.
 */
public class CoordinatesModule extends HudModule {

    private String cachedXyz = "X: 0  Y: 64  Z: 0";
    private String cachedDir = "Facing: North";

    private int lastX = Integer.MIN_VALUE;
    private int lastY = Integer.MIN_VALUE;
    private int lastZ = Integer.MIN_VALUE;

    private static final String[] DIRECTIONS = {"South", "West", "North", "East"};

    public CoordinatesModule() {
        super("Coordinates", "Shows current XYZ position and facing.", 4, 40);
        setWidth(130);
        setHeight(18);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        BlockPos pos = mc.player.getBlockPos();
        int x = pos.getX(), y = pos.getY(), z = pos.getZ();

        if (x != lastX || y != lastY || z != lastZ) {
            lastX = x; lastY = y; lastZ = z;
            cachedXyz = "X: " + x + "  Y: " + y + "  Z: " + z;
        }

        int dirIdx = (int) ((mc.player.getYaw() / 90.0f + 0.5f) & 3);
        cachedDir = "Facing: " + DIRECTIONS[dirIdx & 3];
    }

    @Override
    public void render(HudRenderer renderer, float tickDelta) {
        renderer.drawText(cachedXyz, getX(), getY(),      0xFFFFFFFF, true);
        renderer.drawText(cachedDir, getX(), getY() + 10, 0xFFAAAAAA, true);
    }
}
