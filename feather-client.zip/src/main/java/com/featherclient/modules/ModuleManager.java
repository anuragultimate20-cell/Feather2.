package com.featherclient.modules;

import com.featherclient.config.ConfigManager;
import com.featherclient.modules.hud.*;
import com.featherclient.modules.misc.*;
import com.featherclient.modules.render.*;
import com.featherclient.modules.performance.FpsBoosterModule;
import com.featherclient.modules.performance.LowEndModeModule;
import com.featherclient.performance.PerformanceManager;
import com.featherclient.utils.Logger;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * Central registry for all feature modules.
 *
 * Registers one Fabric tick-event listener and fans out to every
 * enabled module — avoids N separate event subscriptions and keeps
 * overhead to a single virtual-dispatch chain per tick.
 */
public class ModuleManager {

    private final List<Module>         modules      = new ArrayList<>();
    private final ConfigManager        configManager;
    private final PerformanceManager   performanceManager;

    public ModuleManager(ConfigManager configManager, PerformanceManager performanceManager) {
        this.configManager      = configManager;
        this.performanceManager = performanceManager;
    }

    /** Register every module. Called once during mod init. */
    public void registerAll() {
        var cfg = configManager.getConfig();

        // ── HUD modules ──────────────────────────────────────────────
        register(new FpsCounterModule(),   cfg.showFpsCounter);
        register(new CpsDisplayModule(),   cfg.showCps);
        register(new PingDisplayModule(),  cfg.showPing);
        register(new KeystrokesModule(),   cfg.showKeystrokes);
        register(new ArmorHudModule(),     cfg.showArmorHud);
        register(new CoordinatesModule(),  cfg.showCoordinates);

        // ── Movement modules ─────────────────────────────────────────
        register(new ToggleSprintModule(), cfg.toggleSprint);
        register(new ToggleSneakModule(),  cfg.toggleSneak);
        register(new ZoomModule(),         cfg.zoomEnabled);
        register(new FreelookModule(),     cfg.freelookEnabled);

        // ── Render modules ───────────────────────────────────────────
        register(new CrosshairModule(),    cfg.customCrosshair);
        register(new WaypointsModule(),    cfg.waypointsEnabled);
        register(new MotionBlurModule(),   cfg.motionBlur);

        // ── Misc ─────────────────────────────────────────────────────
        register(new ScreenshotModule(),   cfg.screenshotNotification);

        // ── Performance ──────────────────────────────────────────────
        register(new FpsBoosterModule(),   cfg.fpsBoosted);
        register(new LowEndModeModule(),   cfg.lowEndMode || performanceManager.isLowEnd());

        Logger.info("Registered " + modules.size() + " modules.");

        // Single shared tick listener — O(n) but only enabled modules run
        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);
    }

    private void register(Module module, boolean defaultEnabled) {
        if (defaultEnabled) module.setEnabled(true);
        modules.add(module);
    }

    /** Tick all enabled modules. Runs on the client tick thread. */
    private void onClientTick(MinecraftClient client) {
        if (client.player == null) return;
        for (Module m : modules) {
            if (m.isEnabled()) {
                try {
                    m.onTick();
                } catch (Exception e) {
                    // Never let a module crash the game
                    Logger.error("Module " + m.getName() + " tick error: " + e.getMessage());
                }
            }
        }
    }

    // ── Queries ────────────────────────────────────────────────────

    public List<Module> getModules() { return Collections.unmodifiableList(modules); }

    public Optional<Module> getByName(String name) {
        return modules.stream().filter(m -> m.getName().equalsIgnoreCase(name)).findFirst();
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> Optional<T> getByType(Class<T> type) {
        return modules.stream().filter(type::isInstance).map(m -> (T) m).findFirst();
    }

    /** Save current enabled-state back to config, then persist. */
    public void saveState() {
        var cfg = configManager.getConfig();
        getByType(FpsCounterModule.class).ifPresent(m -> cfg.showFpsCounter = m.isEnabled());
        getByType(CpsDisplayModule.class).ifPresent(m -> cfg.showCps = m.isEnabled());
        getByType(PingDisplayModule.class).ifPresent(m -> cfg.showPing = m.isEnabled());
        getByType(KeystrokesModule.class).ifPresent(m -> cfg.showKeystrokes = m.isEnabled());
        getByType(ArmorHudModule.class).ifPresent(m -> cfg.showArmorHud = m.isEnabled());
        getByType(CoordinatesModule.class).ifPresent(m -> cfg.showCoordinates = m.isEnabled());
        getByType(ToggleSprintModule.class).ifPresent(m -> cfg.toggleSprint = m.isEnabled());
        getByType(ToggleSneakModule.class).ifPresent(m -> cfg.toggleSneak = m.isEnabled());
        getByType(ZoomModule.class).ifPresent(m -> cfg.zoomEnabled = m.isEnabled());
        getByType(FreelookModule.class).ifPresent(m -> cfg.freelookEnabled = m.isEnabled());
        getByType(CrosshairModule.class).ifPresent(m -> cfg.customCrosshair = m.isEnabled());
        getByType(WaypointsModule.class).ifPresent(m -> cfg.waypointsEnabled = m.isEnabled());
        getByType(FpsBoosterModule.class).ifPresent(m -> cfg.fpsBoosted = m.isEnabled());
        getByType(LowEndModeModule.class).ifPresent(m -> cfg.lowEndMode = m.isEnabled());
        configManager.save();
    }
}
