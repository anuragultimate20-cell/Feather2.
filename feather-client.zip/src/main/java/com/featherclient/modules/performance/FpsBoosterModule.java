package com.featherclient.modules.performance;

import com.featherclient.modules.Module;
import net.minecraft.client.MinecraftClient;

/**
 * FPS Booster Mode — aggressively reduces visual quality at runtime
 * to maximise frame rate. Intended as a temporary toggle during
 * combat or heavy chunk-loading.
 *
 * Changes applied on enable (restored on disable):
 *  - Particle level   → MINIMAL
 *  - Entity distance  → 50 %
 *  - Mipmap levels    → 0
 *  - Clouds           → OFF
 *  - Fancy graphics   → OFF
 *
 * All changes go through MC's own Options API so they work correctly
 * with Sodium's overrides.
 */
public class FpsBoosterModule extends Module {

    // Saved values to restore when the module is disabled
    private double savedEntityDistance;
    private int    savedMipmap;
    private boolean savedFancy;

    public FpsBoosterModule() {
        super("FPS Booster", Category.PERFORMANCE,
              "Maximises FPS by reducing visual quality temporarily.");
    }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.options == null) return;

        // Snapshot current values
        savedEntityDistance = mc.options.getEntityDistanceScaling().getValue();
        savedMipmap         = mc.options.getMipmapLevels().getValue();
        savedFancy          = mc.options.getFancyGraphics().getValue();

        // Apply boost settings
        mc.options.getEntityDistanceScaling().setValue(0.5);
        mc.options.getMipmapLevels().setValue(0);
        mc.options.getFancyGraphics().setValue(false);
        mc.options.getCloudRenderMode().setValue(net.minecraft.client.option.CloudRenderMode.OFF);
        mc.options.getParticles().setValue(net.minecraft.client.option.ParticlesMode.MINIMAL);

        mc.options.write();
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.options == null) return;

        mc.options.getEntityDistanceScaling().setValue(savedEntityDistance);
        mc.options.getMipmapLevels().setValue(savedMipmap);
        mc.options.getFancyGraphics().setValue(savedFancy);

        mc.options.write();
    }
}
