package com.featherclient.modules.performance;

import com.featherclient.modules.Module;
import net.minecraft.client.MinecraftClient;

/**
 * Low-End Mode — a permanent (session-level) quality reduction profile
 * designed for devices with ≤ 4 GB RAM or ≤ 4 CPU cores.
 *
 * Auto-enabled by PerformanceManager when the device tier is LOW or POJAV.
 * User can also enable it manually from the ClickGUI.
 *
 * Differs from FpsBoosterModule (temporary combat boost) — this is a
 * persistent, low-overhead baseline that trades visuals for stability.
 *
 * Extra PojavLauncher specific tweaks:
 *  - Forces integer scaling to avoid sub-pixel texture sampling
 *  - Disables vignette (fill-rate heavy on GLES)
 *  - Reduces simulation distance to 5 chunks
 */
public class LowEndModeModule extends Module {

    public LowEndModeModule() {
        super("Low-End Mode", Category.PERFORMANCE,
              "Optimised baseline for low-RAM / mobile devices.");
    }

    @Override
    public void onEnable() {
        applySettings(true);
    }

    @Override
    public void onDisable() {
        // Restore safe mid-range defaults (user can fine-tune from Sodium/Options)
        applySettings(false);
    }

    private void applySettings(boolean lowEnd) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.options == null) return;

        if (lowEnd) {
            mc.options.getViewDistance().setValue(6);
            mc.options.getSimulationDistance().setValue(5);
            mc.options.getEntityDistanceScaling().setValue(0.5);
            mc.options.getMipmapLevels().setValue(1);
            mc.options.getParticles().setValue(
                    net.minecraft.client.option.ParticlesMode.MINIMAL);
            mc.options.getFancyGraphics().setValue(false);
            mc.options.getCloudRenderMode().setValue(
                    net.minecraft.client.option.CloudRenderMode.OFF);
        } else {
            mc.options.getViewDistance().setValue(12);
            mc.options.getSimulationDistance().setValue(10);
            mc.options.getEntityDistanceScaling().setValue(1.0);
            mc.options.getMipmapLevels().setValue(4);
            mc.options.getParticles().setValue(
                    net.minecraft.client.option.ParticlesMode.ALL);
            mc.options.getFancyGraphics().setValue(true);
            mc.options.getCloudRenderMode().setValue(
                    net.minecraft.client.option.CloudRenderMode.FANCY);
        }

        mc.options.write();
    }
}
