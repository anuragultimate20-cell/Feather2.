package com.featherclient.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.item.ItemStack;

/**
 * Batched HUD rendering helper.
 *
 * Wraps a Minecraft DrawContext and exposes a simple API for HUD
 * modules so they never call GL methods directly.
 *
 * Key performance rules observed here:
 *  - All drawing is forwarded to DrawContext which batches draw calls
 *    via the VertexConsumerProvider already set up by Minecraft.
 *  - Text shadow is optional per call — shadow doubles draw calls.
 *  - Item rendering delegates to Minecraft's cached item renderer.
 *  - getTextWidth() is O(1) via the cached font metrics atlas.
 */
public class HudRenderer {

    private final DrawContext   ctx;
    private final TextRenderer  fonts;
    private final float         tickDelta;

    public HudRenderer(DrawContext ctx, float tickDelta) {
        this.ctx       = ctx;
        this.fonts     = MinecraftClient.getInstance().textRenderer;
        this.tickDelta = tickDelta;
    }

    // ── Text ─────────────────────────────────────────────────────────

    /**
     * Draw a string at pixel (x, y).
     *
     * @param shadow  true adds a drop-shadow (costs one extra draw call)
     */
    public void drawText(String text, int x, int y, int color, boolean shadow) {
        ctx.drawText(fonts, text, x, y, color, shadow);
    }

    public int getTextWidth(String text) {
        return fonts.getWidth(text);
    }

    // ── Rectangles ───────────────────────────────────────────────────

    /** Draw a filled, axis-aligned rectangle. ARGB color. */
    public void drawRect(int x1, int y1, int x2, int y2, int argb) {
        ctx.fill(x1, y1, x2, y2, argb);
    }

    /**
     * Draw a rectangle with 2-pixel rounded corners (very cheap —
     * just clips the 4 corner pixels without any curve computation).
     */
    public void drawRoundedRect(int x1, int y1, int x2, int y2, int argb, int radius) {
        if (radius <= 0) { drawRect(x1, y1, x2, y2, argb); return; }
        int r = Math.min(radius, Math.min((x2 - x1) / 2, (y2 - y1) / 2));
        // Fill centre cross
        ctx.fill(x1 + r, y1,     x2 - r, y2,     argb);
        ctx.fill(x1,     y1 + r, x1 + r, y2 - r, argb);
        ctx.fill(x2 - r, y1 + r, x2,     y2 - r, argb);
        // Fill corners (quarter circles approximated as squares for perf)
        drawCorner(x1,     y1,     r, argb);
        drawCorner(x2 - r, y1,     r, argb);
        drawCorner(x1,     y2 - r, r, argb);
        drawCorner(x2 - r, y2 - r, r, argb);
    }

    private void drawCorner(int ox, int oy, int r, int argb) {
        // Simple fan approximation — 4 pixels per step
        for (int i = 0; i < r; i++) {
            int span = (int) Math.sqrt((double) r * r - (double) (r - i - 1) * (r - i - 1));
            ctx.fill(ox + r - span, oy + i, ox + r, oy + i + 1, argb);
        }
    }

    // ── Items ────────────────────────────────────────────────────────

    /** Render an item icon at (x, y) using Minecraft's item renderer. */
    public void drawItem(ItemStack stack, int x, int y) {
        ctx.drawItem(stack, x, y);
    }

    // ── Gradient ─────────────────────────────────────────────────────

    public void drawGradientRect(int x1, int y1, int x2, int y2, int colorTop, int colorBottom) {
        ctx.fillGradient(x1, y1, x2, y2, colorTop, colorBottom);
    }

    // ── Passthrough ──────────────────────────────────────────────────

    public DrawContext getContext()  { return ctx;       }
    public float       getTickDelta(){ return tickDelta; }
}
