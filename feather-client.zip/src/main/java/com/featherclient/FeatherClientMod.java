package com.featherclient;

import com.featherclient.config.ConfigManager;
import com.featherclient.modules.ModuleManager;
import com.featherclient.cosmetics.CosmeticsManager;
import com.featherclient.performance.PerformanceManager;
import com.featherclient.gui.GuiThemeManager;
import com.featherclient.utils.Logger;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

/**
 * FeatherClient - Main mod entrypoint.
 *
 * Initialization order matters for performance:
 *   1. PerformanceManager  — detects device capabilities first
 *   2. ConfigManager       — loads user settings
 *   3. GuiThemeManager     — sets up cached UI theme
 *   4. ModuleManager       — registers all feature modules
 *   5. CosmeticsManager    — async-loaded last (non-critical path)
 */
@Environment(EnvType.CLIENT)
public class FeatherClientMod implements ClientModInitializer {

    public static final String MOD_ID   = "featherclient";
    public static final String MOD_NAME = "FeatherClient";
    public static final String VERSION  = "1.0.0";

    // Singleton accessors — never null after onInitializeClient returns
    private static PerformanceManager performanceManager;
    private static ConfigManager      configManager;
    private static ModuleManager      moduleManager;
    private static CosmeticsManager   cosmeticsManager;
    private static GuiThemeManager    guiThemeManager;

    @Override
    public void onInitializeClient() {
        long startMs = System.currentTimeMillis();
        Logger.info("=== " + MOD_NAME + " v" + VERSION + " initializing ===");

        // 1. Detect device capabilities (RAM, CPU, GPU tier)
        performanceManager = new PerformanceManager();
        performanceManager.detectAndApply();

        // 2. Load config from disk (or create defaults)
        configManager = new ConfigManager();
        configManager.load();

        // 3. Build cached GUI theme (no runtime reallocation needed)
        guiThemeManager = new GuiThemeManager(configManager.getGuiTheme());

        // 4. Register every feature module (HUD, toggles, cosmetics, etc.)
        moduleManager = new ModuleManager(configManager, performanceManager);
        moduleManager.registerAll();

        // 5. Cosmetics are low-priority — load asynchronously so the
        //    render thread is never stalled on network or disk I/O.
        cosmeticsManager = new CosmeticsManager();
        cosmeticsManager.loadAsync();

        long elapsed = System.currentTimeMillis() - startMs;
        Logger.info("=== " + MOD_NAME + " ready in " + elapsed + " ms ===");
    }

    // --- Static accessors ---

    public static PerformanceManager getPerformanceManager() { return performanceManager; }
    public static ConfigManager      getConfigManager()      { return configManager;      }
    public static ModuleManager      getModuleManager()      { return moduleManager;      }
    public static CosmeticsManager   getCosmeticsManager()   { return cosmeticsManager;  }
    public static GuiThemeManager    getGuiThemeManager()    { return guiThemeManager;   }
}
