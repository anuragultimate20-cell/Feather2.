package com.featherclient.config;

import com.featherclient.utils.Logger;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/**
 * Manages loading, saving, and hot-reloading of FeatherConfig.
 *
 * Uses atomic file writes (write temp → rename) to avoid config
 * corruption if the process is killed mid-save.
 *
 * Performance notes:
 *  - Config is read once at startup; all runtime access uses the
 *    in-memory FeatherConfig object — no disk I/O in hot paths.
 *  - Gson serialization runs on the calling thread; call save()
 *    from a non-render thread if possible.
 */
public class ConfigManager {

    private static final String CONFIG_FILE = "featherclient.json";
    private static final Gson   GSON        = new GsonBuilder().setPrettyPrinting().create();

    private final Path         configPath;
    private       FeatherConfig config;

    public ConfigManager() {
        this.configPath = FabricLoader.getInstance()
                .getConfigDir()
                .resolve(CONFIG_FILE);
        this.config = new FeatherConfig(); // safe defaults
    }

    /** Load config from disk, or use defaults if missing / corrupt. */
    public void load() {
        if (!Files.exists(configPath)) {
            Logger.info("No config found — using defaults.");
            save(); // write defaults to disk for user reference
            return;
        }
        try {
            String json = Files.readString(configPath);
            FeatherConfig loaded = GSON.fromJson(json, FeatherConfig.class);
            if (loaded != null) {
                config = loaded;
                Logger.info("Config loaded from " + configPath);
            } else {
                Logger.warn("Config file was empty — using defaults.");
            }
        } catch (IOException | com.google.gson.JsonSyntaxException e) {
            Logger.warn("Failed to load config (" + e.getMessage() + ") — using defaults.");
        }
    }

    /**
     * Persist current config atomically.
     * Writes to a temp file first, then renames to prevent corruption.
     */
    public void save() {
        try {
            Path tmp = configPath.resolveSibling(CONFIG_FILE + ".tmp");
            Files.writeString(tmp, GSON.toJson(config));
            Files.move(tmp, configPath, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) {
            Logger.error("Failed to save config: " + e.getMessage());
        }
    }

    /** Reset all settings to their defaults and persist. */
    public void resetToDefaults() {
        config = new FeatherConfig();
        save();
        Logger.info("Config reset to defaults.");
    }

    // --- Accessors ---

    public FeatherConfig getConfig()   { return config;           }
    public String        getGuiTheme() { return config.guiTheme;  }
}
