package com.featherclient.cosmetics;

import com.featherclient.FeatherClientMod;
import com.featherclient.config.FeatherConfig;

/**
 * Handles rendering of the player's equipped cape.
 *
 * Cape rendering hooks into Minecraft's player model via a mixin
 * on the PlayerEntityRenderer. This class holds the simulation state
 * (physics, wave) so the mixin stays clean.
 *
 * Performance notes:
 *  - Cape physics simulation is disabled by default (config.capePhysics).
 *  - When physics is OFF, no simulation runs — the cape is a static quad.
 *  - When physics is ON, a simple spring chain of 4 nodes is simulated
 *    at 20 Hz (tied to game tick, not frame rate) — very cheap.
 *  - Texture is loaded once and cached; no per-frame I/O.
 */
public class CapeRenderer {

    // ── Physics state (only used when capePhysics = true) ────────────

    private static final int NODES = 4;
    private final float[][] nodePos = new float[NODES][3]; // x, y, z per node
    private final float[][] nodeVel = new float[NODES][3];

    private static final float SPRING_STIFFNESS = 0.3f;
    private static final float DAMPING          = 0.85f;
    private static final float GRAVITY          = 0.02f;
    private static final float NODE_DIST        = 0.25f; // metres between nodes

    /** Called each game tick by CapePhysicsTicker when physics is enabled. */
    public void tickPhysics(float playerYaw, float playerPitch,
                            float dx, float dy, float dz) {
        FeatherConfig cfg = FeatherClientMod.getConfigManager().getConfig();
        if (!cfg.capePhysics) return;

        for (int i = 1; i < NODES; i++) {
            // Gravity
            nodeVel[i][1] -= GRAVITY;

            // Spring toward previous node
            float tx = nodePos[i-1][0] - nodePos[i][0];
            float ty = nodePos[i-1][1] - nodePos[i][1] - NODE_DIST;
            float tz = nodePos[i-1][2] - nodePos[i][2];

            nodeVel[i][0] += tx * SPRING_STIFFNESS;
            nodeVel[i][1] += ty * SPRING_STIFFNESS;
            nodeVel[i][2] += tz * SPRING_STIFFNESS;

            // Player motion drag
            nodeVel[i][0] -= dx * 0.1f;
            nodeVel[i][2] -= dz * 0.1f;

            // Damping
            nodeVel[i][0] *= DAMPING;
            nodeVel[i][1] *= DAMPING;
            nodeVel[i][2] *= DAMPING;

            // Integrate
            nodePos[i][0] += nodeVel[i][0];
            nodePos[i][1] += nodeVel[i][1];
            nodePos[i][2] += nodeVel[i][2];
        }
    }

    /** Reset physics state — call when the player teleports or respawns. */
    public void resetPhysics() {
        for (int i = 0; i < NODES; i++) {
            nodePos[i][0] = nodePos[i][1] = nodePos[i][2] = 0;
            nodeVel[i][0] = nodeVel[i][1] = nodeVel[i][2] = 0;
        }
    }

    public float[] getNodePos(int index) { return nodePos[index]; }
}
