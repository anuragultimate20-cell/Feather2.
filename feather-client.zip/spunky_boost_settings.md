# Recommended Spunky Boost + FeatherClient Settings

## Sodium (Rendering)

| Option                      | Recommended Value | Notes |
|-----------------------------|-------------------|-------|
| Graphics Mode               | Fast              | Best FPS |
| Chunk-rendering threads     | 2–3               | Leave cores for gameplay |
| Entity distance             | 75%               | Balance perf/visibility |
| Use Block-face Culling      | On                | Big FPS gain |
| Translucency Sorting        | Dynamic           | Stable with FeatureClient HUD |
| Use Fog Occlusion           | On                | |
| Clouds                      | Off               | |
| Weather                     | Fancy             | Minor cost, safe |
| Leaves                      | Fast              | Significant FPS gain |
| Chunk Update Threads        | 3                 | |
| Mipmap Levels               | 2                 | 4 looks nicer but costs RAM |

## Lithium

Leave all defaults — Lithium has no user-facing options that conflict.

## FerriteCore

Enabled automatically — no config needed.

## ImmediatelyFast

| Option                      | Recommended Value |
|-----------------------------|-------------------|
| Enabled                     | On                |
| HUD Batching                | On                |
| Entity Batching             | On                |
| Font Renderer               | On                |

## EntityCulling

| Option                      | Recommended Value |
|-----------------------------|-------------------|
| Enabled                     | On                |
| Start delay                 | 0 ms              |
| Tick interval               | 4                 |

## MoreCulling

All defaults — works passively alongside EntityCulling.

## Iris Shaders

Recommendation: Use **No Shader** or a lite pack like **Vanilla+** / **Complementary Unbound (Performance)**.  
FeatherClient's Motion Blur is off by default to avoid double-blur with shader packs.

---

## FeatherClient-Specific Settings for Spunky Boost

Open ClickGUI (Right-Shift) and configure:

| Module         | Setting                  | Value |
|----------------|--------------------------|-------|
| FPS Booster    | Enable during combat     | Optional |
| Low-End Mode   | Auto-enabled on ≤4 GB    | Leave as detected |
| Motion Blur    | Enabled                  | Off (keep off with Iris) |
| Waypoint Beam  | Beam visible             | Off (expensive) |
| Cape Physics   | Simulate physics         | Off (saves CPU) |
| Particles      | Particle level           | Decreased |

---

## JVM Arguments (for maximum performance)

Add to your Fabric launcher profile:

```
-Xmx4G
-XX:+UseG1GC
-XX:+ParallelRefProcEnabled
-XX:MaxGCPauseMillis=200
-XX:+UnlockExperimentalVMOptions
-XX:+DisableExplicitGC
-XX:+AlwaysPreTouch
-XX:G1NewSizePercent=30
-XX:G1MaxNewSizePercent=40
-XX:G1HeapRegionSize=8M
-XX:G1ReservePercent=20
-XX:G1HeapWastePercent=5
-XX:G1MixedGCCountTarget=4
-XX:InitiatingHeapOccupancyPercent=15
-XX:G1MixedGCLiveThresholdPercent=90
-XX:G1RSetUpdatingPauseTimePercent=5
-XX:SurvivorRatio=32
-XX:+PerfDisableSharedMem
-XX:MaxTenuringThreshold=1
```

For PojavLauncher (4 GB RAM device):
```
-Xmx2G -Xms512M
-XX:+UseG1GC
-XX:MaxGCPauseMillis=50
-XX:G1HeapRegionSize=32M
-XX:G1NewSizePercent=20
-XX:G1ReservePercent=20
-Dpojav_launcher=1
```
